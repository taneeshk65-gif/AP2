package main

import (
	"bytes"
	"database/sql"
	"encoding/json"
	"log"
	"net/http"
	"time"

	"github.com/google/uuid"

	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
)

var db *sql.DB

type Order struct {
	ID         string    `json:"id"`
	CustomerID string    `json:"customer_id"`
	ItemName   string    `json:"item_name"`
	Amount     int64     `json:"amount"`
	Status     string    `json:"status"`
	CreatedAt  time.Time `json:"created_at"`
}

func main() {
	// CONNECT DB
	connStr := "host=localhost port=5432 user=postgres password=1234 dbname=order_db sslmode=disable"

	var err error
	db, err = sql.Open("postgres", connStr)
	if err != nil {
		log.Fatal(err)
	}

	err = db.Ping()
	if err != nil {
		log.Fatal(err)
	}

	log.Println("✅ Connected to PostgreSQL")

	r := gin.Default()

	client := &http.Client{
		Timeout: 2 * time.Second,
	}

	r.POST("/orders", func(c *gin.Context) {
		var req struct {
			CustomerID string `json:"customer_id"`
			ItemName   string `json:"item_name"`
			Amount     int64  `json:"amount"`
		}

		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(400, gin.H{"error": err.Error()})
			return
		}

		order := Order{
			ID:         uuid.New().String(),
			CustomerID: req.CustomerID,
			ItemName:   req.ItemName,
			Amount:     req.Amount,
			Status:     "Pending",
			CreatedAt:  time.Now(),
		}

		_, err := db.Exec(
			"INSERT INTO orders (id, customer_id, item_name, amount, status, created_at) VALUES ($1,$2,$3,$4,$5,$6)",
			order.ID, order.CustomerID, order.ItemName, order.Amount, order.Status, order.CreatedAt,
		)

		if err != nil {
			c.JSON(500, gin.H{"error": "DB insert failed"})
			return
		}

		payload := map[string]interface{}{
			"order_id": order.ID,
			"amount":   order.Amount,
		}

		body, _ := json.Marshal(payload)

		resp, err := client.Post(
			"http://localhost:8081/payments",
			"application/json",
			bytes.NewBuffer(body),
		)

		if err != nil {
			c.JSON(503, gin.H{"error": "payment service unavailable"})
			return
		}

		var paymentResp map[string]interface{}
		json.NewDecoder(resp.Body).Decode(&paymentResp)

		status := "Failed"
		if paymentResp["status"] == "Authorized" {
			status = "Paid"
		}

		db.Exec("UPDATE orders SET status=$1 WHERE id=$2", status, order.ID)

		order.Status = status

		c.JSON(200, order)
	})

	r.Run(":8080")
}
