package main

import (
	"context"
	"log"
	"net"

	pb "microservices-project/payment-service/proto"

	"google.golang.org/grpc"
)

type server struct {
	pb.UnimplementedPaymentServiceServer
}

func (s *server) CreatePayment(ctx context.Context, req *pb.PaymentRequest) (*pb.PaymentResponse, error) {
	log.Println("💰 Payment created for order:", req.OrderId)

	return &pb.PaymentResponse{
		Id:      "pay_123",
		OrderId: req.OrderId,
		Amount:  req.Amount,
		Status:  "SUCCESS",
	}, nil
}

func (s *server) GetPayment(ctx context.Context, req *pb.GetPaymentRequest) (*pb.PaymentResponse, error) {
	log.Println("🔍 Fetch payment for order:", req.OrderId)

	return &pb.PaymentResponse{
		Id:      "pay_123",
		OrderId: req.OrderId,
		Amount:  500,
		Status:  "SUCCESS",
	}, nil
}

func main() {
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatal(err)
	}

	grpcServer := grpc.NewServer()

	pb.RegisterPaymentServiceServer(grpcServer, &server{})

	log.Println("🚀 gRPC Payment Service running on port 50051")

	if err := grpcServer.Serve(lis); err != nil {
		log.Fatal(err)
	}
}
