package main

import (
	"database/sql"
	"log"

	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
)

var db *sql.DB

func main() {
	// CONNECT DB
	connStr := "host=localhost port=5432 user=postgres password=1234 dbname=payment_db sslmode=disable"

	var err error
	db, err = sql.Open("postgres", connStr)
	if err != nil {
		log.Fatal(err)
	}

	err = db.Ping()
	if err != nil {
		log.Fatal(err)
	}

	log.Println("✅ Payment DB Connected")

	r := gin.Default()

	// CREATE PAYMENT
	r.POST("/payments", func(c *gin.Context) {
		var req struct {
			OrderID string `json:"order_id"`
			Amount  int64  `json:"amount"`
		}

		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(400, gin.H{"error": err.Error()})
			return
		}

		status := "Authorized"
		if req.Amount > 100000 {
			status = "Declined"
		}

		// INSERT INTO DB
		_, err := db.Exec(
			"INSERT INTO payments (id, order_id, transaction_id, amount, status) VALUES ($1,$2,$3,$4,$5)",
			req.OrderID, req.OrderID, "txn_123", req.Amount, status,
		)

		if err != nil {
			c.JSON(500, gin.H{"error": "DB insert failed"})
			return
		}

		c.JSON(200, gin.H{
			"status":         status,
			"transaction_id": "txn_123",
		})
	})

	// GET PAYMENT
	r.GET("/payments/:order_id", func(c *gin.Context) {
		orderID := c.Param("order_id")

		var status string
		err := db.QueryRow(
			"SELECT status FROM payments WHERE order_id=$1",
			orderID,
		).Scan(&status)

		if err != nil {
			c.JSON(404, gin.H{"error": "not found"})
			return
		}

		c.JSON(200, gin.H{"status": status})
	})

	r.Run(":8081")
}
