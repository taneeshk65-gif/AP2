package main

import (
	"database/sql"
	"log"

	"microservices-project/order-service/internal/repository"
	handler "microservices-project/order-service/internal/transport/http"
	"microservices-project/order-service/internal/usecase"

	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
)

func main() {

	connStr := "host=localhost port=5432 user=postgres password=1234 dbname=order_db sslmode=disable"

	db, err := sql.Open("postgres", connStr)
	if err != nil {
		log.Fatal(err)
	}

	err = db.Ping()
	if err != nil {
		log.Fatal("DB connection failed:", err)
	}

	log.Println("✅ Connected to DB")

	repo := repository.NewOrderRepository(db)
	usecase := usecase.NewOrderUsecase(repo)
	h := handler.NewHandler(usecase)

	r := gin.Default()

	h.RegisterRoutes(r)

	r.Run(":8081")
}
