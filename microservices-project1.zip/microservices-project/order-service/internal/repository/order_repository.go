package repository

import (
	"database/sql"
	"microservices-project/order-service/internal/domain"
)

type OrderRepository struct {
	DB *sql.DB
}

func NewOrderRepository(db *sql.DB) *OrderRepository {
	return &OrderRepository{DB: db}
}

func (r *OrderRepository) Create(order *domain.Order) error {
	query := `
	INSERT INTO orders (id, customer_id, item_name, amount, status, created_at)
	VALUES ($1, $2, $3, $4, $5, $6)
	`
	_, err := r.DB.Exec(query,
		order.ID,
		order.CustomerID,
		order.ItemName,
		order.Amount,
		order.Status,
		order.CreatedAt,
	)
	return err
}

func (r *OrderRepository) GetByID(id string) (*domain.Order, error) {
	query := `SELECT id, customer_id, item_name, amount, status, created_at FROM orders WHERE id=$1`

	row := r.DB.QueryRow(query, id)

	var order domain.Order
	err := row.Scan(
		&order.ID,
		&order.CustomerID,
		&order.ItemName,
		&order.Amount,
		&order.Status,
		&order.CreatedAt,
	)

	return &order, err
}
