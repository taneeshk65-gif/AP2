package usecase

import (
	"context"
	"log"
	"time"

	pb "microservices-project/payment-service/proto"

	"google.golang.org/grpc"

	"microservices-project/order-service/internal/domain"
	"microservices-project/order-service/internal/repository"

	"github.com/google/uuid"
)

type OrderUsecase struct {
	Repo *repository.OrderRepository
}

func NewOrderUsecase(repo *repository.OrderRepository) *OrderUsecase {
	return &OrderUsecase{Repo: repo}
}

func (u *OrderUsecase) CreateOrder(customerID, itemName string, amount int64) (*domain.Order, error) {

	order := &domain.Order{
		ID:         uuid.New().String(),
		CustomerID: customerID,
		ItemName:   itemName,
		Amount:     amount,
		Status:     "Pending",
		CreatedAt:  time.Now(),
	}

	err := u.Repo.Create(order)
	if err != nil {
		return nil, err
	}

	// 🔥 gRPC CALL

	conn, err := grpc.Dial("localhost:50051", grpc.WithInsecure())
	if err != nil {
		log.Println("❌ gRPC connection failed:", err)
		order.Status = "Failed"
		return order, nil
	}
	defer conn.Close()

	client := pb.NewPaymentServiceClient(conn)

	resp, err := client.CreatePayment(context.Background(), &pb.PaymentRequest{
		OrderId: order.ID,
		Amount:  float64(order.Amount),
	})

	if err != nil {
		log.Println("❌ Payment failed:", err)
		order.Status = "Failed"
		return order, nil
	}

	if resp.Status == "SUCCESS" {
		order.Status = "Paid"
	} else {
		order.Status = "Failed"
	}

	return order, nil
}
