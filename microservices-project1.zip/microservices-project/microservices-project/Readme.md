# Microservices Project using gRPC and Clean Architecture

## 🚀 Overview

This project demonstrates a microservices-based system using:

* **Order Service (HTTP - REST API)**
* **Payment Service (gRPC)**
* **Inter-service communication using gRPC**
* **Clean Architecture principles**

---

## 🧱 Architecture

* Client sends request to **Order Service (HTTP)**
* Order Service processes business logic
* Order Service calls **Payment Service via gRPC**
* Payment Service processes payment
* Order status updated based on response
![Architecture](assets/architecture.png)

---

## 📁 Project Structure

```
microservices-project/
│
├── order-service/
│   ├── cmd/service/main.go
│   └── internal/
│       ├── domain/
│       ├── repository/
│       ├── usecase/
│       └── transport/http/
│
├── payment-service/
│   ├── cmd/main.go
│   └── proto/
│
├── proto/
│   ├── payment.proto
│   ├── payment.pb.go
│   └── payment_grpc.pb.go
│
└── go.mod
```

---

## ⚙️ Technologies Used

* Go (Golang)
* gRPC
* Protocol Buffers
* Gin (HTTP framework)
* PostgreSQL (optional)

---

## 🔌 Ports Used

| Service                | Port  |
| ---------------------- | ----- |
| Order Service (HTTP)   | 8081  |
| Payment Service (gRPC) | 50051 |

---

## ▶️ How to Run

### 1. Run Payment Service (gRPC)

```
cd payment-service
go run cmd/main.go
```

---

### 2. Run Order Service

```
cd order-service
go run cmd/service/main.go
```

---

## 🧪 API Testing

### Create Order

```
POST http://localhost:8081/orders
```

### Request Body:

```json
{
  "customer_id": "123",
  "item_name": "Phone",
  "amount": 50000
}
```

---

## 🔄 Flow

1. Client sends order request
2. Order is created
3. gRPC call is made to Payment Service
4. Payment is processed
5. Order status updated to "Paid"

---

## 💡 Key Concepts

### gRPC

High-performance communication protocol using Protocol Buffers.

### Protocol Buffers

Used to define service contracts and message structures.

### Clean Architecture

Separates code into layers:

* Domain
* Usecase
* Repository
* Transport

---

## 🎯 Features

* REST API for Order Service
* gRPC communication between services
* Clean Architecture implementation
* Modular and scalable design

---

## 🏁 Conclusion

This project demonstrates how microservices communicate using gRPC and how Clean Architecture improves maintainability and scalability.
